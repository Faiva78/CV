<?php
include_once '../myFuncs.php';
if (M_isGet("Lang")) {
    if (M_checkGet("Lang", "IT")) {
        include_once './PersInfoIT.php'; 
    } elseif (M_checkGet("lang", "ES")) {
        include_once './PersInfoES.php'; 
    } else {
        include_once './PersInfoEN.php'; 
    }
}
?>



