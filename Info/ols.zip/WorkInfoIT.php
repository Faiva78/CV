
<?php
include_once '../include/db.php';
include_once '../myFuncs.php';
global $mysqli;

// implementare le intestazioni tabella inserendole nel primo record
// e di conseguenza spostare le letture di un record in più
// invece che in un array 

// separare la tabella con cui si forma la stringa sql in una variabile tipo:
// "persinfo"+"EN", in modo da passare dal menu la variabile lingua $lang, per poter così
// mostrarele figgerenti lingue. 
$KeyTableStr="table";
$Table="";
if (M_isGet($KeyTableStr)){
        $Table=  M_get($KeyTableStr);
}
var_dump($Table);
$QuantiLav = Query("SELECT count(Id) FROM ".$Table);
$quantiLavori = mysqli_fetch_array($QuantiLav);
$Qlav = ($quantiLavori[0]);

$IntesSql = Query("SELECT * FROM ".$Table." where id=1");
$intestazioni = mysqli_fetch_array($IntesSql);

//  --- Start table composing -------------
echo '<table class="CvTable">';
echo '<col width="50%">';
for ($xx = 2; $xx <= $Qlav; $xx++) {
    $res = Query("SELECT * FROM ".$Table." where id=" . $xx);
    $result = mysqli_fetch_array($res);
    $fields = ($res->field_count);
    echo '<tr><td>';
    echo '<table  class="CvTable" >';
    echo '<col width="25%">';
    for ($x = 2 ; $x < ($fields ); $x++) {
        echo '<tr >';
        // implementare una funzione che se passata la stringa come una riga sola la codifica come <a>
        // se invece più righe viene codificata come <UL> UNORDERED LIST
        echo '  <td class="CvDesc">' . M_RetToUL($intestazioni[$x]) . '</td>';
        echo '  <td class="CvData">' . M_RetToUL($result[$x])    . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    echo '<hr>';
    echo '</td></tr>';
}
echo '</table>';
?>