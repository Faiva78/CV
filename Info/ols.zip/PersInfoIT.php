<table  class="CvTable" >
    <col width="25%">
    </tr>
    <tr>
        <td  style="font-size: larger" colspan="2">
            <a>Informazioni Personali</a>
           <img src="info/Img/qr.jpg" alt="qr" style="width: 50px;height: 50px" >

            <a  ></a>
        </td>
        <td class="CvData"><a></a></td>
    </tr>
    <tr >
        <td class="CvDesc"><a>Nome</a></td>
        <td class="CvData"><A>Nicola Teso</A></td>
    </tr>
    <tr>
        <td  class="CvDesc"><a>Indirizzo</a></td>
        <td class="CvData"><a>202 Dunaflor Verde, int 1184 - 35100 – Campo Internacional – Las Palmas - Spagna</a></td>
    </tr>
    <tr>
        <td class="CvDesc"><a>Telefono</a></td>
        <td class="CvData"><a>+34 602 181 402<br>+39 320 79 66 989</a></td>
    </tr>


    <tr>
        <td class="CvDesc"><a>Email</a></td>
        <td class="CvData"><a>Tesonicola@gmail.com</a></td>
    </tr>
    <tr>
        <td class="CvDesc"><a>Nazionalità</a></td>
        <td class="CvData"><a>Italiana</a></td>
    </tr>

    <tr>
        <td class="CvDesc"><a>Data di nascita</a></td>
        <td class="CvData"><a>1 Aprile 1978</a></td>
    </tr>

    <tr>
        <td class="CvDesc"><a></a></td>
        <td class="CvData"><a></a></td>
    </tr>
</table>