
<?php
include_once '../include/db.php';
include_once '../myFuncs.php';
global $mysqli;

$etichette = array(
    "",
    "Data (da)",
    "Data (a)",
    "Nome e tipo di istituto di istruzione o formazione",
    "Principali materie / abilità professionali oggetto dello studio",
    "Qualifica conseguita"
);
$QuantiLav = Query("SELECT count(Id) FROM istruzione");
$quantiLavori = mysqli_fetch_array($QuantiLav);
$Qlav = ($quantiLavori[0]);
echo '<table class="CvTable2">';
echo '<col width="100%">';
for ($xx = 1; $xx <= $Qlav; $xx++) {
    $res = Query("SELECT * FROM istruzione where id=" . $xx);
    $result = mysqli_fetch_array($res);
    $fields = ($res->field_count);
    echo '<tr><td>';
    echo '<table  class="CvTable2" >';
    echo '<col width="100%">';
    
    echo '  <tr >';
    echo '      <td class="CvDesc">' . M_RetToA($etichette[1])      .'</td>';
    echo '      <td class="CvData">' . M_RetToA($result[1]).'</td>';
    echo '  </tr>';
    
    echo '  <tr >';
    echo '      <td class="CvDesc">' . M_RetToA($etichette[2])      .'</td>';
    echo '      <td class="CvData">' . M_RetToA($result[2]).'</td>';
    echo '  </tr>'; 
    
    echo '  <tr >';
    echo '      <td class="CvDesc">' . M_RetToA($etichette[3])      .'</td>';
    echo '      <td class="CvData">' . M_RetToA($result[3]).'</td>';
    echo '  </tr>'; 
    
    for ($x = 4; $x < ($fields ); $x++) {
        echo '<tr >';
        echo '  <td class="CvDesc">' .M_RetToA($etichette[$x]) . '</td>';
        echo '  <td class="CvData">' . M_RetToUL($result[$x])    . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    echo '<hr>';
    echo '</td></tr>';
}
echo '</table>';
?>