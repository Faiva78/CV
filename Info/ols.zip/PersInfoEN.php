<table style="width: 50%" >
    <tr>
        <td>Name</td>
        <td>Nicola</td>
    </tr>
    <tr>
        <td>Surnamet<d>
        <td>Teso</td>

    </tr>

</table>