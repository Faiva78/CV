<?php
include_once '../include/db.php';
include_once '../myFuncs.php';
global $mysqli;

$etichette = array(
    "",
    "Data (da)",
    "Data (a)",
    "Nome e indirizzo del datore di lavoro",
    "Tipo di azienda o settore",
    "Tipo di impiego",
    "Principali mansioni e responsabilità"
);
?>
<meta charset="UTF-8" http-equiv="Content-Type" content="text/html;charset=UTF-8">
<table  class="CvTable" >
    <col width="25%">
    </tr>
    <tr>
        <td  style="font-size: larger" colspan="2">
            <a>Esperienza lavorativa</a>         
        </td>
        <td class="CvData"><a></a></td>
    </tr>
    <tr>
        <td  class="CvDesc" colspan="2"><a>z</a></td>
        <td class="CvData"><a> </a></td>
    </tr>
<?php
$QuantiLav = Query("SELECT count(Id) FROM Lavori");
$quantiLavori = mysqli_fetch_array($QuantiLav);
$Qlav = ($quantiLavori[0]);
for ($xx = 1; $xx <= $Qlav; $xx++) {
    $res = Query("SELECT * FROM Lavori where id=" . $xx);
    $result = mysqli_fetch_array($res);
    $fields = ($res->field_count);

    for ($x = 1; $x < ($fields - 1); $x++) {
        echo '<tr >';
        echo '<td class="CvDesc">' .M_RetToA($etichette[$x]) . '</td>';
        echo '<td class="CvData">' . M_RetToA($result[$x])    . '</td>';
        echo '</tr>';
    }
    echo '<tr >';
    echo '<td class="CvDesc">' . M_RetToA($etichette[$fields-1])      .'</td>';
    echo '<td class="CvData">' . M_RetToUL($result[$fields-1]).'</td>';
    echo '</tr>'; 
    echo '<tr>';
    echo '<td class="CvDesc" colspan="2"><a>z</a></td>';
    echo '<td class="CvData"></td>';
    echo '</tr>';
}
?>
</table>