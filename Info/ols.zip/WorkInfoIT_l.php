<?php 
$data="Date (da – a)";
$datore="Nome e indirizzo del datore di lavoro";
$Settore="Tipo di azienda o settore";
$Impiego="Tipo di impiego";
$Mansioni="Principali mansioni e responsabilità";

//Inserire qui loop per i lavori usando array

$lavori = array(
    "1"=> array(
        "1"=>"Giugno 2009 -  Luglio 2015",
        "2"=>"Ittica Center S.r.l. - Via Baracca 80, Cavallino-Treporti 30100 – Venezia ­ Italia",
        "3"=>"Commercio prodotti ittici – Ingrosso pesce",
        "4"=>"Impiegato – Capo Reparto Spedizioni",
        "5"=>"<ul > 
                   <li>>Elaborazione ed evasione ordini computerizzato di clienti e fornitori.</li>
                   <li>Gestione e manutenzione di programmi e apparecchiature informatiche professionali.</li>
                   <li>Progettazione, scrittura e manutenzione di programmi di utilità per l'ottimizzazione delle vendite, le procedure di inventario, di getione del magazzino e promozione vendite ai clienti.</li>
                   <li> Relazioni di collaborazione, coordinamento e consulenza con la casa informatica fornitrice dei servizi I.T.</li>
                   <il>Analisi statistica delle vendite, di inventario e di produttività.</il>
                   <li>Gestione social media, design di sito web, gestione e crezione dei contenuti, grafica pubblicitaria.</li>
                   <li>Configurazione e gestione etichette e codici a barre.</li>
             </ul> "
    )
)

?>






<table  class="CvTable" >
    
    <col width="25%">
    </tr>
    <tr>
        <td  style="font-size: larger" colspan="2">
            <a>Esperienza lavorativa</a>         
        </td>
        <td class="CvData"><a></a></td>
    </tr>
    <!-- Job section 1 -->
    <tr>
        <td  class="CvDesc"><a></a></td>
        <td class="CvData"><a> </a></td>
    </tr>

    <tr >
        <td class="CvDesc"><a><?php echo $data ?></a></td>
        <td class="CvData"><A><?php echo $lavori["1"]["1"]  ?></A></td>
    </tr>

    <tr>
        <td class="CvDesc"><a><?php echo $datore ?></a></td>
        <td class="CvData"><a><?php echo $lavori["1"]["2"]  ?> </a></td>
    </tr>

    <tr>
        <td class="CvDesc"><a><?php echo $Settore ?></a></td>
        <td class="CvData"><a><?php echo $lavori["1"]["3"] ?></a></td>
    </tr>

    <tr>
        <td class="CvDesc"><a><?php echo $Impiego ?></a></td>
        <td class="CvData"><a><?php echo $lavori["1"]["4"]?> </a></td>
    </tr>
    <tr>
        <td class="CvDesc"><a><?php echo $Mansioni ?></a></td>
        <td class="CvData"><a><?php echo  $lavori["1"]["5"]?> </a></td>
    </tr>
    <!-- END ----Job section 1  ----END -->


    <tr>
        <td class="CvDesc"><a></a></td>
        <td class="CvData"><a></a></td>
    </tr>
</table>