<table style="width: 50%" >
    <tr>
        <td>>Nombre</td>
        <td>Nicola</td>
    </tr>
    <tr>
        <td>Appellido</td>
        <td>Teso</td>
    </tr>

</table>